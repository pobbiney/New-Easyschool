<?php
    $educationLevels = \App\Models\StaffDoc::educationLevels();
    $oldRows = old('qualifications');
    $qualificationRows = [];

    if (is_array($oldRows) && count($oldRows)) {
        foreach ($oldRows as $row) {
            $qualificationRows[] = [
                'id' => $row['id'] ?? '',
                'level' => $row['level'] ?? '',
                'qualification' => $row['qualification'] ?? '',
                'institution' => $row['institution'] ?? '',
                'year' => $row['year'] ?? '',
                'document_path' => $row['document_path'] ?? '',
            ];
        }
    } elseif (!empty($existingQualifications) && count($existingQualifications)) {
        foreach ($existingQualifications as $doc) {
            $qualificationRows[] = [
                'id' => $doc->id,
                'level' => $doc->level,
                'qualification' => $doc->qualification,
                'institution' => $doc->institution,
                'year' => $doc->year,
                'document_path' => $doc->document_path,
            ];
        }
    }

    if (!count($qualificationRows)) {
        $qualificationRows = [[
            'id' => '',
            'level' => '',
            'qualification' => '',
            'institution' => '',
            'year' => '',
            'document_path' => '',
        ]];
    }

    $maxYear = (int) date('Y') + 1;
?>

<div class="staff-form-card shadow-1 radius-12 bg-base overflow-hidden mt-24" id="academic-qualifications-section">
    <div class="card-header border-bottom bg-base py-16 px-24 d-flex flex-wrap align-items-center justify-content-between gap-3">
        <div class="d-flex align-items-center gap-12">
            <span class="section-title-icon"><i class="ri-graduation-cap-line"></i></span>
            <div>
                <h6 class="text-lg fw-semibold mb-0 section-card-title">Academic Qualifications</h6>
                <p class="text-sm text-secondary-light mb-0">Add every academic qualification. Certificate upload is optional.</p>
            </div>
        </div>
        <button type="button" class="btn btn-outline-primary-600 d-flex align-items-center gap-6" id="addQualificationRow">
            <i class="ri-add-line"></i>
            Add qualification
        </button>
    </div>
    <div class="card-body p-24">
        <div id="qualificationRows">
            <?php $__currentLoopData = $qualificationRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('staff.partials._qualification-row', [
                    'index' => $index,
                    'row' => $row,
                    'educationLevels' => $educationLevels,
                    'maxYear' => $maxYear,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php $__errorArgs = ['qualifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger-600 d-block mt-8"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div id="removedQualificationIds"></div>
    </div>
</div>

<template id="qualificationRowTemplate">
    <?php echo $__env->make('staff.partials._qualification-row', [
        'index' => '__INDEX__',
        'row' => [
            'id' => '',
            'level' => '',
            'qualification' => '',
            'institution' => '',
            'year' => '',
            'document_path' => '',
        ],
        'educationLevels' => $educationLevels,
        'maxYear' => $maxYear,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</template>
<?php /**PATH C:\xampp\htdocs\easyschool\resources\views/staff/partials/_section-academic-qualifications.blade.php ENDPATH**/ ?>