
<?php
    $section = $section ?? null;
    $crumbs = $crumbs ?? [];
    $title = $title ?? null;
    $subtitle = $subtitle ?? null;
    $actions = $actions ?? null;

    if (! $title && ! empty($crumbs)) {
        $lastCrumb = end($crumbs);
        if (! empty($lastCrumb['active']) || empty($lastCrumb['url'])) {
            $title = $lastCrumb['label'] ?? null;
        }
    }

    $trailCrumbs = $crumbs;
    if ($title && count($trailCrumbs) > 0) {
        $last = end($trailCrumbs);
        if (($last['label'] ?? '') === $title) {
            array_pop($trailCrumbs);
        }
    }
?>

<div class="page-header breadcrumb d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24" data-ph-enhanced="1">
    <div>
        <?php if($section): ?>
            <h1 class="fw-semibold mb-4 h6 text-primary-light"><?php echo e(strtoupper($section)); ?></h1>
        <?php endif; ?>

        <?php if($title): ?>
            <h2 class="ph-page-title"><?php echo e($title); ?></h2>
        <?php endif; ?>

        <?php if(! empty($trailCrumbs)): ?>
            <div class="ph-trail" data-ph-enhanced="1">
                <?php $__currentLoopData = $trailCrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(! $loop->first): ?>
                        <span class="ph-sep"><i class="ri-arrow-right-s-line"></i></span>
                    <?php endif; ?>
                    <?php if(! empty($crumb['url']) && empty($crumb['active'])): ?>
                        <a href="<?php echo e($crumb['url']); ?>" class="hover-text-primary"><?php echo e($crumb['label']); ?></a>
                    <?php elseif($loop->last): ?>
                        <span class="ph-current"><?php echo e($crumb['label']); ?></span>
                    <?php else: ?>
                        <span><?php echo e($crumb['label']); ?></span>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php if($subtitle): ?>
            <p class="text-neutral-600 mt-4 mb-0"><?php echo e($subtitle); ?></p>
        <?php endif; ?>
    </div>

    <?php if(! empty($actions)): ?>
        <div class="page-header__actions">
            <?php echo $actions; ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\easyschool\resources\views/partials/_page-header.blade.php ENDPATH**/ ?>