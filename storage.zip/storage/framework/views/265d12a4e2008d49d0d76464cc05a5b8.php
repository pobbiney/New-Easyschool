<?php
    $index = $index ?? 0;
    $row = $row ?? [];
    $educationLevels = $educationLevels ?? \App\Models\StaffDoc::educationLevels();
    $maxYear = $maxYear ?? ((int) date('Y') + 1);
    $rowId = $row['id'] ?? '';
    $rowLevel = $row['level'] ?? '';
    $rowQualification = $row['qualification'] ?? '';
    $rowInstitution = $row['institution'] ?? '';
    $rowYear = $row['year'] ?? '';
    $rowDocument = $row['document_path'] ?? '';
?>

<div class="qualification-row border radius-12 p-20 mb-16" data-qualification-row>
    <?php if($rowId !== ''): ?>
        <input type="hidden" name="qualifications[<?php echo e($index); ?>][id]" value="<?php echo e($rowId); ?>">
    <?php endif; ?>
    <?php if($rowDocument !== ''): ?>
        <input type="hidden" name="qualifications[<?php echo e($index); ?>][document_path]" value="<?php echo e($rowDocument); ?>">
    <?php endif; ?>
    <div class="d-flex align-items-start justify-content-between gap-12 mb-16">
        <span class="qualification-row-label text-sm fw-semibold">Qualification <span data-qualification-number></span></span>
        <button type="button" class="btn btn-sm btn-outline-danger-600 d-flex align-items-center gap-4 remove-qualification-row" data-existing-id="<?php echo e($rowId); ?>">
            <i class="ri-delete-bin-line"></i>
            Remove
        </button>
    </div>
    <div class="row gy-3">
        <div class="col-md-6">
            <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Educational Level</label>
            <select name="qualifications[<?php echo e($index); ?>][level]" class="form-control form-select">
                <option value="">Select level</option>
                <?php if($rowLevel !== '' && !in_array($rowLevel, $educationLevels, true)): ?>
                    <option value="<?php echo e($rowLevel); ?>" selected><?php echo e($rowLevel); ?></option>
                <?php endif; ?>
                <?php $__currentLoopData = $educationLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($level); ?>" <?php echo e($rowLevel === $level ? 'selected' : ''); ?>><?php echo e($level); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ["qualifications.$index.level"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Year of Completion</label>
            <input type="number" name="qualifications[<?php echo e($index); ?>][year]" class="form-control"
                min="1950" max="<?php echo e($maxYear); ?>" value="<?php echo e($rowYear); ?>" placeholder="e.g. <?php echo e(date('Y')); ?>">
            <?php $__errorArgs = ["qualifications.$index.year"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Qualification / Award</label>
            <input type="text" name="qualifications[<?php echo e($index); ?>][qualification]" class="form-control"
                value="<?php echo e($rowQualification); ?>" placeholder="e.g. B.Ed Mathematics, WASSCE">
            <?php $__errorArgs = ["qualifications.$index.qualification"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Institution</label>
            <input type="text" name="qualifications[<?php echo e($index); ?>][institution]" class="form-control"
                value="<?php echo e($rowInstitution); ?>" placeholder="e.g. University of Ghana">
            <?php $__errorArgs = ["qualifications.$index.institution"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12">
            <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Certificate (optional)</label>
            <input type="file" name="qualifications[<?php echo e($index); ?>][document]" class="form-control"
                accept=".pdf,.jpg,.jpeg,.png,.webp">
            <?php if(!empty($rowDocument)): ?>
                <small class="text-secondary-light d-block mt-6">
                    Current file:
                    <a href="<?php echo e(asset('uploads/staffdocs/' . $rowDocument)); ?>" target="_blank" rel="noopener">View certificate</a>
                </small>
            <?php endif; ?>
            <?php $__errorArgs = ["qualifications.$index.document"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\easyschool\resources\views/staff/partials/_qualification-row.blade.php ENDPATH**/ ?>