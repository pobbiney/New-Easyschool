<?php
    $mode = $mode ?? 'pending';
    $periodQuery = array_filter([
        'academic_year_id' => request('academic_year_id'),
        'academic_term_id' => request('academic_term_id'),
    ], fn ($value) => $value !== null && $value !== '');
    $typePillClass = fn (?string $type) => 'ac-pill-' . ($type ?: 'slate');
    $typeIcon = fn (?string $type) => match ($type) {
        'homework' => 'ri-booklet-line',
        'class_test' => 'ri-file-edit-line',
        'exam' => 'ri-file-shield-2-line',
        'class_assignment' => 'ri-task-line',
        default => 'ri-file-list-3-line',
    };
?>

<?php if($assessments->isNotEmpty()): ?>
<div class="ah-toolbar">
    <div class="ah-filter-pills">
        <button type="button" class="ah-filter-pill is-active" data-filter="all">All</button>
        <?php $__currentLoopData = $assessmentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessmentType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" class="ah-filter-pill" data-filter="<?php echo e($assessmentType->slug); ?>"><?php echo e($assessmentType->name); ?></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <input type="text" id="ahSearch" class="form-control radius-4" placeholder="Search assessments..." style="min-width:220px;max-width:280px;">
</div>
<div class="ac-list-scroll dataTable-wrapper">
    <table class="table mb-0 data-table" id="dataTable">
        <thead>
            <tr>
                <th>Assessment</th>
                <th>Type</th>
                <th>Term</th>
                <th>Class</th>
                <th>Subject</th>
                <th>Max</th>
                <th>Scored</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $scored = $assessment->scores->whereNotNull('score')->count();
                $searchText = strtolower($assessment->title . ' ' . ($assessment->schoolClass?->name ?? '') . ' ' . ($assessment->course?->name ?? '') . ' ' . ($assessment->academicTerm?->name ?? '') . ' ' . ($assessment->academicYear?->name ?? ''));
            ?>
            <tr class="ah-assessment-row" data-type="<?php echo e($assessment->type); ?>" data-search="<?php echo e($searchText); ?>">
                <td>
                    <div class="ah-assessment-title">
                        <span class="ah-assessment-icon <?php echo e($assessment->type); ?>"><i class="<?php echo e($typeIcon($assessment->type)); ?>"></i></span>
                        <div>
                            <span class="fw-semibold d-block"><?php echo e($assessment->title); ?></span>
                            <span class="ah-assessment-meta">
                                <?php if($assessment->assessment_date): ?>
                                    <?php echo e($assessment->assessment_date->format('d M Y')); ?>

                                <?php else: ?>
                                    No date set
                                <?php endif; ?>
                                <?php if($assessment->due_date): ?>
                                    · Due <?php echo e($assessment->due_date->format('d M')); ?>

                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                </td>
                <td><span class="ac-pill <?php echo e($typePillClass($assessment->type)); ?>"><?php echo e($assessment->typeLabel()); ?></span></td>
                <td>
                    <span class="ac-pill ac-pill-indigo"><?php echo e($assessment->academicTerm?->name ?? '—'); ?></span>
                    <?php if($assessment->academicYear?->name): ?>
                        <span class="d-block text-xs text-secondary-light mt-1"><?php echo e($assessment->academicYear->name); ?></span>
                    <?php endif; ?>
                </td>
                <td><span class="ac-pill ac-pill-teal"><?php echo e($assessment->schoolClass?->name); ?></span></td>
                <td><span class="ac-pill ac-pill-indigo"><?php echo e($assessment->course?->name ?? 'Homeroom'); ?></span></td>
                <td><span class="ac-pill ac-pill-violet"><?php echo e(number_format($assessment->max_score, 0)); ?> pts</span></td>
                <td><span class="ac-pill ac-pill-slate"><?php echo e($scored); ?> scored</span></td>
                <td><span class="ac-pill ac-pill-<?php echo e($assessment->status === 'published' ? 'published' : 'draft'); ?>"><?php echo e(ucfirst($assessment->status)); ?></span></td>
                <td>
                    <div class="ac-action-pills">
                        <a href="<?php echo e(route('teacher-assessment-scores', $assessment)); ?>" class="ac-action-pill ac-action-pill-rose">
                            <i class="ri-edit-2-line"></i> <?php echo e($mode === 'records' ? 'View Scores' : 'Enter Scores'); ?>

                        </a>
                        <?php if($mode === 'pending'): ?>
                            <form action="<?php echo e(route('teacher-assessments-delete', $assessment)); ?>" method="POST" class="ah-action-form"
                                data-confirm-title="Delete this assessment?"
                                data-confirm="This cannot be undone.">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="ac-action-pill ac-action-pill-amber">
                                    <i class="ri-delete-bin-line"></i> Delete
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php if($mode === 'pending'): ?>
    <?php echo $__env->make('teacher.partials._assessment-delete-notice', ['assessments' => $assessments], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>
<?php else: ?>
<div class="ah-empty-assessments">
    <span class="ac-avatar d-flex align-items-center justify-content-center"><i class="<?php echo e($mode === 'records' ? 'ri-archive-line' : 'ri-file-add-line'); ?>"></i></span>
    <h6 class="fw-semibold mb-8"><?php echo e($mode === 'records' ? 'No scored assessments yet' : 'All caught up'); ?></h6>
    <p class="text-secondary-light mb-20">
        <?php if($mode === 'records'): ?>
            Assessments move here automatically once marks are entered.
        <?php else: ?>
            Every assessment for this term already has marks entered, or none have been created yet.
        <?php endif; ?>
    </p>
    <?php if($mode === 'records'): ?>
        <a href="<?php echo e(route('teacher-assessments', $periodQuery)); ?>" class="btn btn-primary-600">
            <i class="ri-arrow-left-line"></i> Back to Assessments
        </a>
    <?php else: ?>
        <button type="button" class="btn btn-primary-600" data-bs-toggle="modal" data-bs-target="#createAssessmentModal">
            <i class="ri-add-line"></i> Create Assessment
        </button>
        <?php if(($stats['records'] ?? 0) > 0): ?>
            <a href="<?php echo e(route('teacher-assessment-records', $periodQuery)); ?>" class="btn btn-outline-primary-600 ms-2">
                <i class="ri-archive-line"></i> View <?php echo e($stats['records']); ?> record<?php echo e($stats['records'] === 1 ? '' : 's'); ?>

            </a>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\easyschool\resources\views/teacher/partials/_assessments-hub-list.blade.php ENDPATH**/ ?>