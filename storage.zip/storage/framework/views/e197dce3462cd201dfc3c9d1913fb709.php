<?php $title = 'Class Report Cards — '.$className; ?>

<?php $__env->startSection('content'); ?>
<div class="print-sheet print-sheet--terminal">
    <div class="print-toolbar no-print">
        <button type="button" onclick="window.print()" class="print-btn print-btn-secondary">
            <i class="ri-printer-line"></i> Print All
        </button>
        <button type="button" onclick="window.close()" class="print-btn print-btn-primary">
            <i class="ri-close-line"></i> Close
        </button>
    </div>

    <div class="no-print" style="margin-bottom: 24px;padding:18px 34px;text-align:center;">
        <h1 style="margin:0 0 8px;font-size:18px;">Class Report Cards</h1>
        <p style="margin:0;color:#64748b;font-size:13px;">
            <?php echo e($className); ?>

            <?php if(!empty($period['year_name'])): ?>
                · <?php echo e($period['year_name']); ?> / <?php echo e($period['term_name']); ?>

            <?php endif; ?>
            · <?php echo e($reports->count()); ?> student<?php echo e($reports->count() === 1 ? '' : 's'); ?>

            · Printed <?php echo e($printedAt->format('d M Y g:i A')); ?>

        </p>
    </div>

    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('teacher.partials._report-card-page', [
            'report' => $report,
            'school' => $school,
            'printedAt' => $printedAt,
            'period' => $period,
            'withPageBreak' => ! $loop->last,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .print-sheet--terminal::before { display: none; }
    .print-sheet--terminal { box-shadow: none; border-radius: 0; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.print', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\easyschool\resources\views/teacher/print-class-report-cards.blade.php ENDPATH**/ ?>