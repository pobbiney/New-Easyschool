<?php
    $periodQuery = array_filter([
        'academic_year_id' => $period['year_id'] ?? null,
        'academic_term_id' => $period['term_id'] ?? null,
    ], fn ($value) => $value !== null && $value !== '');
?>

<form method="GET" action="<?php echo e($periodFilterAction ?? url()->current()); ?>" class="ah-period-filter d-flex flex-wrap align-items-end gap-3" id="ahPeriodFilter">
    <?php $__currentLoopData = request()->except(['academic_year_id', 'academic_term_id', 'page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(is_array($value)): ?>
            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" name="<?php echo e($key); ?>[]" value="<?php echo e($item); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div>
        <label for="ah_academic_year_id" class="form-label text-xs fw-semibold text-secondary-light mb-4">Academic Year</label>
        <select name="academic_year_id" id="ah_academic_year_id" class="form-select radius-4" style="min-width:160px;">
            <?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year->id); ?>" <?php if((string) ($period['year_id'] ?? '') === (string) $year->id): echo 'selected'; endif; ?>><?php echo e($year->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div>
        <label for="ah_academic_term_id" class="form-label text-xs fw-semibold text-secondary-light mb-4">Term</label>
        <select name="academic_term_id" id="ah_academic_term_id" class="form-select radius-4" style="min-width:140px;">
            <?php $__currentLoopData = $academicTerms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($term->id); ?>" <?php if((string) ($period['term_id'] ?? '') === (string) $term->id): echo 'selected'; endif; ?>><?php echo e($term->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <?php if(!empty($period['year_name']) && !empty($period['term_name'])): ?>
        <div class="pb-1">
            <span class="ac-pill ac-pill-indigo"><i class="ri-calendar-line"></i> <?php echo e($period['year_name']); ?> · <?php echo e($period['term_name']); ?></span>
        </div>
    <?php endif; ?>
</form>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('ahPeriodFilter');
    if (!form) {
        return;
    }

    form.querySelectorAll('select').forEach(function (select) {
        select.addEventListener('change', function () {
            form.submit();
        });
    });
});
</script>
<?php /**PATH C:\xampp\htdocs\easyschool\resources\views/teacher/partials/_academic-period-filter.blade.php ENDPATH**/ ?>