<?php
    $employee = $datas ?? null;
    $departments = $departments ?? collect();
    $positions = $positions ?? collect();
    $payGrades = $payGrades ?? collect();
    $earningTypes = $earningTypes ?? collect();
    $deductionTypes = $deductionTypes ?? collect();
    $assignedEarnings = $assignedEarnings ?? [];
    $assignedDeductions = $assignedDeductions ?? [];
    $employmentTypes = ['Permanent', 'Contract', 'National Service', 'Intern', 'Casual'];
?>

<div class="staff-form-card shadow-1 radius-12 bg-base overflow-hidden mt-24">
    <div class="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center gap-12">
        <span class="section-title-icon"><i class="ri-building-4-line"></i></span>
        <div>
            <h6 class="text-lg fw-semibold mb-0 section-card-title">Organisation &amp; Contract</h6>
            <p class="text-sm text-secondary-light mb-0">Department, role, and employment dates.</p>
        </div>
    </div>
    <div class="card-body p-24">
        <div class="row gy-3">
            <div class="col-md-4">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Department</label>
                <select name="department_id" class="form-control form-select">
                    <option value="">Select department</option>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>" <?php echo e((string) old('department_id', $employee->department_id ?? '') === (string) $department->id ? 'selected' : ''); ?>>
                            <?php echo e($department->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Position <span class="text-danger-600">*</span></label>
                <?php if($positions->count()): ?>
                    <select name="position_id" id="staff_position_id" class="form-control form-select"
                        data-teacher-position-id="<?php echo e($teacherPositionId ?? ''); ?>"
                        data-teacher-category-id="<?php echo e($teacherCategoryId ?? ''); ?>">
                        <option value="">Select position</option>
                        <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($position->id); ?>" <?php echo e((string) old('position_id', $employee->position_id ?? '') === (string) $position->id ? 'selected' : ''); ?>>
                                <?php echo e($position->name); ?><?php if($position->department): ?> — <?php echo e($position->department->name); ?><?php endif; ?>
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['position_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php else: ?>
                    <input type="text" name="position" class="form-control" value="<?php echo e(old('position', $employee->position ?? '')); ?>" placeholder="e.g. Mathematics Teacher">
                    <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Employment Type</label>
                <select name="employment_type" class="form-control form-select">
                    <option value="">Select type</option>
                    <?php $__currentLoopData = $employmentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type); ?>" <?php echo e(old('employment_type', $employee->employment_type ?? '') === $type ? 'selected' : ''); ?>><?php echo e($type); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Appointment Date</label>
                <input type="date" name="appointment_date" class="form-control" value="<?php echo e(old('appointment_date', optional($employee)->appointment_date?->format('Y-m-d') ?? $employee->appointment_date ?? '')); ?>">
            </div>
            <div class="col-md-4">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Confirmation Date</label>
                <input type="date" name="confirmation_date" class="form-control" value="<?php echo e(old('confirmation_date', optional($employee)->confirmation_date?->format('Y-m-d') ?? $employee->confirmation_date ?? '')); ?>">
            </div>
            <div class="col-md-4">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Contract End Date</label>
                <input type="date" name="contract_end_date" class="form-control" value="<?php echo e(old('contract_end_date', optional($employee)->contract_end_date?->format('Y-m-d') ?? $employee->contract_end_date ?? '')); ?>">
            </div>
        </div>
    </div>
</div>

<div class="staff-form-card shadow-1 radius-12 bg-base overflow-hidden mt-24">
    <div class="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center gap-12">
        <span class="section-title-icon"><i class="ri-bank-card-line"></i></span>
        <div>
            <h6 class="text-lg fw-semibold mb-0 section-card-title">Statutory, Bank &amp; Next of Kin</h6>
            <p class="text-sm text-secondary-light mb-0">SSNIT, TIN, salary account, and emergency contact.</p>
        </div>
    </div>
    <div class="card-body p-24">
        <div class="row gy-3">
            <div class="col-md-6">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">SSNIT Number</label>
                <input type="text" name="ssnit_number" class="form-control" value="<?php echo e(old('ssnit_number', $employee->ssnit_number ?? '')); ?>" placeholder="SSNIT number">
            </div>
            <div class="col-md-6">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">TIN</label>
                <input type="text" name="tin" class="form-control" value="<?php echo e(old('tin', $employee->tin ?? '')); ?>" placeholder="GRA TIN">
            </div>
            <div class="col-md-6">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Bank Name</label>
                <input type="text" name="bank_name" class="form-control" value="<?php echo e(old('bank_name', $employee->bank_name ?? '')); ?>">
            </div>
            <div class="col-md-6">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Branch</label>
                <input type="text" name="bank_branch" class="form-control" value="<?php echo e(old('bank_branch', $employee->bank_branch ?? '')); ?>">
            </div>
            <div class="col-md-6">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Account Name</label>
                <input type="text" name="account_name" class="form-control" value="<?php echo e(old('account_name', $employee->account_name ?? '')); ?>">
            </div>
            <div class="col-md-6">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Account Number</label>
                <input type="text" name="account_number" class="form-control" value="<?php echo e(old('account_number', $employee->account_number ?? '')); ?>">
            </div>
            <div class="col-md-4">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Next of Kin</label>
                <input type="text" name="next_of_kin_name" class="form-control" value="<?php echo e(old('next_of_kin_name', $employee->next_of_kin_name ?? '')); ?>">
            </div>
            <div class="col-md-4">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Next of Kin Phone</label>
                <input type="text" name="next_of_kin_phone" class="form-control" value="<?php echo e(old('next_of_kin_phone', $employee->next_of_kin_phone ?? '')); ?>">
            </div>
            <div class="col-md-4">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Relationship</label>
                <input type="text" name="next_of_kin_relationship" class="form-control" value="<?php echo e(old('next_of_kin_relationship', $employee->next_of_kin_relationship ?? '')); ?>" placeholder="e.g. Spouse">
            </div>
        </div>
    </div>
</div>

<div class="staff-form-card shadow-1 radius-12 bg-base overflow-hidden mt-24">
    <div class="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center gap-12">
        <span class="section-title-icon"><i class="ri-money-cny-circle-line"></i></span>
        <div>
            <h6 class="text-lg fw-semibold mb-0 section-card-title">Compensation</h6>
            <p class="text-sm text-secondary-light mb-0">Pay grade, basic salary, and recurring items. Leave amount blank to skip.</p>
        </div>
    </div>
    <div class="card-body p-24">
        <div class="row gy-3">
            <div class="col-md-6">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Pay Grade</label>
                <select name="pay_grade_id" id="payGradeSelect" class="form-control form-select">
                    <option value="">Select pay grade</option>
                    <?php $__currentLoopData = $payGrades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($grade->id); ?>" data-basic="<?php echo e($grade->basic_salary); ?>"
                            <?php echo e((string) old('pay_grade_id', $employee->pay_grade_id ?? '') === (string) $grade->id ? 'selected' : ''); ?>>
                            <?php echo e($grade->name); ?> (<?php echo e(\App\Support\Money::ghs($grade->basic_salary)); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Basic Salary Override</label>
                <input type="number" step="0.01" min="0" name="basic_salary" id="basicSalaryInput" class="form-control"
                    value="<?php echo e(old('basic_salary', $employee->basic_salary ?? '')); ?>" placeholder="Leave blank to use pay grade">
            </div>
        </div>

        <?php if($earningTypes->count()): ?>
            <h6 class="text-sm fw-semibold mt-20 mb-12">Recurring allowances</h6>
            <div class="row gy-3">
                <?php $__currentLoopData = $earningTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $oldAmount = old('earnings.'.$type->id, $assignedEarnings[$type->id] ?? ''); ?>
                    <div class="col-md-4">
                        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8"><?php echo e($type->name); ?></label>
                        <input type="number" step="0.01" min="0" name="earnings[<?php echo e($type->id); ?>]" class="form-control"
                            value="<?php echo e($oldAmount); ?>" placeholder="<?php echo e($type->method === 'percent_basic' ? '% of basic' : 'Amount'); ?>">
                        <small class="text-secondary-light">Default: <?php echo e($type->method === 'percent_basic' ? $type->default_amount.'%' : \App\Support\Money::ghs($type->default_amount)); ?></small>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php if($deductionTypes->where('is_statutory', false)->count()): ?>
            <h6 class="text-sm fw-semibold mt-20 mb-12">Recurring deductions</h6>
            <div class="row gy-3">
                <?php $__currentLoopData = $deductionTypes->where('is_statutory', false); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $oldAmount = old('deductions.'.$type->id, $assignedDeductions[$type->id] ?? ''); ?>
                    <div class="col-md-4">
                        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8"><?php echo e($type->name); ?></label>
                        <input type="number" step="0.01" min="0" name="deductions[<?php echo e($type->id); ?>]" class="form-control"
                            value="<?php echo e($oldAmount); ?>" placeholder="Amount">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const categorySelect = document.getElementById('staff_user_cat');
        const positionSelect = document.getElementById('staff_position_id');
        if (!categorySelect || !positionSelect) return;

        const teacherPositionId = positionSelect.getAttribute('data-teacher-position-id');
        const teacherCategoryId = positionSelect.getAttribute('data-teacher-category-id');
        if (!teacherPositionId || !teacherCategoryId) return;

        const syncTeacherPosition = function () {
            if (String(categorySelect.value) === String(teacherCategoryId)) {
                positionSelect.value = teacherPositionId;
            }
        };

        categorySelect.addEventListener('change', syncTeacherPosition);
        syncTeacherPosition();
    });
</script>
<?php /**PATH C:\xampp\htdocs\easyschool\resources\views/staff/partials/_section-hr-employment.blade.php ENDPATH**/ ?>