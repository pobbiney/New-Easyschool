<?php
    $pageName = "timetable";
    $subpageName = "timetable";
    $printQuery = array_filter([
        'academic_year_id' => $period['year_id'] ?? null,
        'academic_term_id' => $period['term_id'] ?? null,
    ]);
?>


<?php $__env->startSection('css'); ?>
<?php echo $__env->make('partials._academic-ui-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<style>
    .tt-grid-wrap { overflow-x: auto; }
    .tt-grid { min-width: 860px; margin: 0; }
    .tt-grid th, .tt-grid td { vertical-align: middle; }
    .tt-time {
        min-width: 150px;
        white-space: nowrap;
        background: #f8fafc;
        font-weight: 600;
    }
    .tt-time small { display: block; font-weight: 500; color: #64748b; }
    .tt-cell { min-width: 140px; }
    .tt-subject { font-weight: 700; display: block; font-size: 13px; }
    .tt-teacher { display: block; font-size: 11px; color: #64748b; margin-top: 2px; }
    .tt-kind {
        text-align: center;
        font-weight: 700;
        font-size: 12px;
        letter-spacing: .04em;
        text-transform: uppercase;
        color: #64748b;
        background: #f8fafc;
    }
    .tt-kind.is-break { background: #fffbeb; color: #b45309; }
    .tt-kind.is-assembly { background: #eef2ff; color: #4338ca; }
    .tt-empty { text-align: center; padding: 48px 16px; color: #64748b; }
    .tt-empty i { font-size: 34px; color: #25A194; display: block; margin-bottom: 8px; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-body">
    <?php echo $__env->make('partials._page-header', [
        'section' => 'Timetable',
        'crumbs' => [
            ['label' => 'Dashboard', 'url' => route('dashboard')],
            ['label' => 'Class Timetables', 'url' => route('timetable')],
            ['label' => $class->name, 'url' => null, 'active' => true],
        ],
        'title' => $class->name.' timetable',
        'subtitle' => ($class->category?->name ?: 'Class').($class->classTeacher ? ' · '.$class->classTeacher->full_name : ''),
        'actions' => view('timetable.partials._show-actions', compact('class', 'period', 'printQuery'))->render(),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="card ac-list-wrapper mb-24">
        <div class="card-header py-16 px-24 d-flex flex-wrap align-items-center justify-content-between gap-12">
            <h6 class="mb-0 fw-semibold">Weekly grid</h6>
            <?php echo $__env->make('teacher.partials._academic-period-filter', ['periodFilterAction' => route('timetable-show', $class)], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <?php if(! $timetable): ?>
            <div class="tt-empty">
                <i class="ri-calendar-schedule-line"></i>
                No timetable for <?php echo e($class->name); ?> in the selected year and term.
                <div class="mt-16">
                    <a class="btn btn-primary-600" href="<?php echo e(route('timetable-periods', array_filter(['school_class_id' => $class->id, 'day' => 1, 'academic_year_id' => $period['year_id'], 'academic_term_id' => $period['term_id']]))); ?>">
                        <i class="ri-time-line"></i> Set <?php echo e($class->name); ?> Monday to Friday
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="tt-grid-wrap">
                <table class="table bordered-table mb-0 tt-grid">
                    <thead>
                        <tr>
                            <th>Time</th>
                            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($dayName); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="tt-time">
                                    <?php echo e($slot->label); ?>

                                    <small><?php echo e($slot->timeLabel()); ?></small>
                                </td>
                                <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $dayName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($slot->kind !== 'lesson'): ?>
                                        <td class="tt-kind is-<?php echo e($slot->kind); ?>"><?php echo e($slot->label); ?></td>
                                    <?php else: ?>
                                        <?php $entry = $grid[$day][$slot->id] ?? null; ?>
                                        <td class="tt-cell">
                                            <?php if($entry?->course): ?>
                                                <span class="ac-pill ac-pill-<?php echo e($themes[$entry->course_id] ?? 'teal'); ?>"><?php echo e($entry->course->name); ?></span>
                                                <?php if($entry->teacher): ?>
                                                    <span class="tt-teacher"><?php echo e($entry->teacher->full_name); ?></span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-secondary-light">—</span>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\easyschool\resources\views/timetable/show.blade.php ENDPATH**/ ?>