<?php
    $student = $student ?? null;
    $selectedYearId = old('academic_year_id');
    if ($selectedYearId === null) {
        $selectedYearId = $student?->academic_year_id ?? ($defaultAcademicYearId ?? '');
    }
    $selectedTermId = old('academic_term_id');
    if ($selectedTermId === null) {
        $selectedTermId = $student?->academic_term_id ?? ($defaultAcademicTermId ?? '');
    }
?>
<div class="row gy-3">
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Student ID <span class="text-danger-600">*</span></label>
        <input type="text" name="student_id" class="form-control" value="<?php echo e(old('student_id', $student?->student_id ?? $studentCode ?? '')); ?>" readonly>
        <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Academic Year <span class="text-danger-600">*</span></label>
        <select name="academic_year_id" class="form-control form-select wizard-required">
            <option value="" disabled <?php echo e($selectedYearId ? '' : 'selected'); ?>>Select Academic Year</option>
            <?php $__empty_1 = true; $__currentLoopData = $academicYears ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($year->id); ?>" <?php echo e((string) $selectedYearId === (string) $year->id ? 'selected' : ''); ?>><?php echo e($year->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option value="" disabled>No academic years found — add them first</option>
            <?php endif; ?>
        </select>
        <?php $__errorArgs = ['academic_year_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Academic Term <span class="text-danger-600">*</span></label>
        <select name="academic_term_id" class="form-control form-select wizard-required">
            <option value="" disabled <?php echo e($selectedTermId ? '' : 'selected'); ?>>Select Academic Term</option>
            <?php $__empty_1 = true; $__currentLoopData = $academicTerms ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($term->id); ?>" <?php echo e((string) $selectedTermId === (string) $term->id ? 'selected' : ''); ?>><?php echo e($term->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option value="" disabled>No academic terms found</option>
            <?php endif; ?>
        </select>
        <?php $__errorArgs = ['academic_term_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Class <span class="text-danger-600">*</span></label>
        <select name="school_class_id" class="form-control form-select wizard-required">
            <option value="" disabled <?php echo e(old('school_class_id', $student?->school_class_id ?? '') ? '' : 'selected'); ?>>Select Class</option>
            <?php $__empty_1 = true; $__currentLoopData = $schoolClasses ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($class->id); ?>" <?php echo e(old('school_class_id', $student?->school_class_id ?? '') == $class->id ? 'selected' : ''); ?>><?php echo e($class->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option value="" disabled>No classes found — add them first</option>
            <?php endif; ?>
        </select>
        <?php $__errorArgs = ['school_class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">First Name <span class="text-danger-600">*</span></label>
        <input type="text" name="firstname" class="form-control wizard-required" value="<?php echo e(old('firstname', $student?->firstname ?? '')); ?>" placeholder="Enter first name">
        <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Other Name</label>
        <input type="text" name="othername" class="form-control" value="<?php echo e(old('othername', $student?->othername ?? '')); ?>" placeholder="Enter other name">
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Surname <span class="text-danger-600">*</span></label>
        <input type="text" name="surname" class="form-control wizard-required" value="<?php echo e(old('surname', $student?->surname ?? '')); ?>" placeholder="Enter surname">
        <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Category</label>
        <select name="category" class="form-control form-select">
            <option value="" disabled selected>Select Category</option>
            <?php $__currentLoopData = ['Day Student', 'Boarding', 'Scholarship', 'International']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cat); ?>" <?php echo e(old('category', $student?->category ?? '') == $cat ? 'selected' : ''); ?>><?php echo e($cat); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Gender <span class="text-danger-600">*</span></label>
        <select name="gender" class="form-control form-select wizard-required">
            <option value="" disabled selected>Select Gender</option>
            <option value="Male" <?php echo e(old('gender', $student?->gender ?? '') == 'Male' ? 'selected' : ''); ?>>Male</option>
            <option value="Female" <?php echo e(old('gender', $student?->gender ?? '') == 'Female' ? 'selected' : ''); ?>>Female</option>
        </select>
        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Date of Birth <span class="text-danger-600">*</span></label>
        <input type="text" name="dob" class="form-control datepicker wizard-required" value="<?php echo e(old('dob', $student?->dob ?? '')); ?>" placeholder="Enter date of birth">
        <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Phone</label>
        <input type="tel" name="phone" class="form-control" value="<?php echo e(old('phone', $student?->phone ?? '')); ?>" placeholder="Enter phone number">
        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Email</label>
        <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $student?->email ?? '')); ?>" placeholder="Enter email">
    </div>
    <div class="col-xxl-3 col-xl-4 col-sm-6">
        <label class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Status <span class="text-danger-600">*</span></label>
        <?php
            $selectedStatus = old('status', $student?->status ?? 'Active');
            if ($selectedStatus === 'Draft') {
                $selectedStatus = 'Active';
            }
        ?>
        <select name="status" class="form-control form-select wizard-required">
            <option value="Active" <?php echo e($selectedStatus == 'Active' ? 'selected' : ''); ?>>Active</option>
            <option value="Inactive" <?php echo e($selectedStatus == 'Inactive' ? 'selected' : ''); ?>>Inactive</option>
        </select>
        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\easyschool\resources\views/student/partials/_section-personal.blade.php ENDPATH**/ ?>