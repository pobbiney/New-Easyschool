<?php $pageName = "leave"; $subpageName = "leave-application"; ?>


<?php $__env->startSection('css'); ?>
<?php echo $__env->make('partials._academic-ui-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-body">
    <div class="page-header breadcrumb d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
        <div>
            <h1 class="fw-semibold mb-4 h6 text-primary-light">LEAVE</h1>
            <div>
                <a href="<?php echo e(route('dashboard')); ?>" class="text-secondary-light hover-text-primary hover-underline">Dashboard</a>
                <span class="text-secondary-light"> / Request leave</span>
            </div>
        </div>
    </div>

    <div class="ac-hero d-flex align-items-start gap-16 mb-24">
        <span class="ac-avatar" style="width:52px;height:52px;font-size:22px;"><i class="ri-calendar-event-line"></i></span>
        <div>
            <h5 class="fw-semibold mb-6">Request leave</h5>
            <p class="text-sm text-secondary-light mb-0">Apply for your own leave. An administrator or HR approves or rejects the request.</p>
        </div>
    </div>

    <?php if(! $staff): ?>
        <div class="card ac-list-wrapper">
            <div class="card-body text-center py-56 px-24">
                <span class="ac-pill ac-pill-amber mb-12"><i class="ri-information-line"></i> Staff record required</span>
                <p class="text-secondary-light mb-0">Your login is not linked to a staff record, so leave cannot be submitted. Ask an administrator to link your account.</p>
            </div>
        </div>
    <?php else: ?>
        <div class="row gy-4 mb-24">
            <?php $__empty_1 = true; $__currentLoopData = $balances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-sm-6 col-xl-3">
                    <div class="ac-stat-card h-100">
                        <p class="text-secondary-light text-sm mb-4"><?php echo e($balance->leaveType?->name); ?></p>
                        <h4 class="fw-semibold mb-4"><?php echo e($balance->remaining()); ?> <span class="text-sm fw-medium text-secondary-light">days left</span></h4>
                        <p class="text-xs text-secondary-light mb-0"><?php echo e($balance->taken); ?> used of <?php echo e($balance->entitled); ?> in <?php echo e($year); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <p class="text-sm text-secondary-light mb-0">No leave types are available for you yet.</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="card ac-list-wrapper mb-24">
            <div class="card-header py-16 px-24">
                <h6 class="mb-0 fw-semibold">New leave request</h6>
                <p class="text-sm text-secondary-light mb-0 mt-4">This request is for <?php echo e($staff->full_name); ?> and stays pending until it is reviewed.</p>
            </div>
            <div class="card-body p-24">
                <form method="POST" action="<?php echo e(route('leave-application-process')); ?>" class="row gy-3">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-4">
                        <label class="text-sm fw-semibold text-primary-light mb-8">Leave type</label>
                        <select name="leave_type_id" class="form-control form-select" required>
                            <option value="">Select type</option>
                            <?php $__currentLoopData = $leaveTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>" <?php echo e((string) old('leave_type_id') === (string) $type->id ? 'selected' : ''); ?>>
                                    <?php echo e($type->name); ?> (<?php echo e($type->days_per_year); ?> days<?php echo e($type->is_paid ? '' : ', unpaid'); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['leave_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4">
                        <label class="text-sm fw-semibold text-primary-light mb-8">Start date</label>
                        <input type="date" name="start_date" class="form-control" value="<?php echo e(old('start_date')); ?>" required>
                        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4">
                        <label class="text-sm fw-semibold text-primary-light mb-8">End date</label>
                        <input type="date" name="end_date" class="form-control" value="<?php echo e(old('end_date')); ?>" required>
                        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12">
                        <label class="text-sm fw-semibold text-primary-light mb-8">Reason <span class="text-secondary-light fw-normal">(optional)</span></label>
                        <input type="text" name="reason" class="form-control" value="<?php echo e(old('reason')); ?>" placeholder="Short note for the approver">
                    </div>
                    <div class="col-12">
                        <button class="btn btn-primary-600 d-inline-flex align-items-center gap-6">
                            <i class="ri-send-plane-line"></i> Submit request
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card ac-list-wrapper">
            <div class="card-header py-16 px-24 d-flex align-items-center justify-content-between">
                <h6 class="mb-0 fw-semibold">My requests</h6>
                <span class="text-sm text-secondary-light"><?php echo e($requests->count()); ?> record<?php echo e($requests->count() === 1 ? '' : 's'); ?></span>
            </div>
            <div class="table-responsive">
                <table class="table bordered-table mb-0">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Period</th>
                            <th>Days</th>
                            <th>Reason</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="fw-semibold"><?php echo e($leave->leaveType?->name); ?></td>
                                <td>
                                    <div class="fw-medium"><?php echo e($leave->start_date->format('d M Y')); ?></div>
                                    <span class="text-sm text-secondary-light">to <?php echo e($leave->end_date->format('d M Y')); ?></span>
                                </td>
                                <td><?php echo e($leave->days); ?></td>
                                <td><?php echo e($leave->reason ?: '—'); ?></td>
                                <td>
                                    <?php
                                        $statusClass = $leave->status === 'approved' ? 'ac-pill-emerald' : ($leave->status === 'rejected' ? 'ac-pill-rose' : 'ac-pill-amber');
                                    ?>
                                    <span class="ac-pill <?php echo e($statusClass); ?>"><?php echo e(ucfirst($leave->status)); ?></span>
                                    <?php if($leave->review_note): ?>
                                        <span class="d-block text-sm text-secondary-light mt-4"><?php echo e($leave->review_note); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-secondary-light py-24">You have not applied for leave yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\easyschool\resources\views/teacher/leave.blade.php ENDPATH**/ ?>