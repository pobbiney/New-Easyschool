<?php $title = 'Report Card — '.$report['student']->full_name; ?>

<?php $__env->startSection('content'); ?>
<div class="print-sheet print-sheet--terminal">
    <div class="print-toolbar no-print">
        <button type="button" onclick="window.print()" class="print-btn print-btn-secondary">
            <i class="ri-printer-line"></i> Print
        </button>
        <button type="button" onclick="window.close()" class="print-btn print-btn-primary">
            <i class="ri-close-line"></i> Close
        </button>
    </div>

    <?php echo $__env->make('teacher.partials._report-card-page', [
        'report' => $report,
        'school' => $school,
        'printedAt' => $printedAt,
        'period' => $period,
        'withPageBreak' => false,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .print-sheet--terminal::before { display: none; }
    .print-sheet--terminal { box-shadow: none; border-radius: 0; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.print', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\easyschool\resources\views/teacher/print-report-card.blade.php ENDPATH**/ ?>