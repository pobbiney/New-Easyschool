<?php $title = 'School Bill'; ?>

<?php $__env->startSection('content'); ?>
<div class="print-sheet">
    <div class="print-toolbar no-print">
        <button type="button" onclick="window.print()" class="print-btn print-btn-secondary">
            <i class="ri-printer-line"></i> Print
        </button>
        <button type="button" onclick="window.close()" class="print-btn print-btn-primary">
            <i class="ri-close-line"></i> Close
        </button>
    </div>

    <?php echo $__env->make('billing.partials._print-bill-statement-page', [
        'student' => $student,
        'bills' => $bills,
        'compulsoryBills' => $compulsoryBills,
        'optionalBills' => $optionalBills,
        'arrears' => $arrears,
        'summary' => $summary,
        'filterLabels' => $filterLabels,
        'school' => $school,
        'printedAt' => $printedAt,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.print', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\easyschool\resources\views/billing/print-student-bill-statement.blade.php ENDPATH**/ ?>